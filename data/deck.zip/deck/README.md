# Styling
Styling options are inspired by react-native styling Objects.
Individual Styles override the default style defined in meta.json.

Everything else should be self explanatory :)